﻿namespace SportsLeague.Domain.Entities
{
    // Clase que representa la alineación de un jugador en un partido
    public class MatchLineup : AuditBase
    {
        
        public int MatchId { get; set; }

        public int PlayerId { get; set; }

       
        public bool IsStarter { get; set; }

     
        public string Position { get; set; } = string.Empty;

       
        public Match Match { get; set; } = null!;

        // Relación con la entidad Player
        // Permite acceder a la información completa del jugador
        public Player Player { get; set; } = null!;
    }
}
